// Dados do cardápio
const cardapioData = {
    lanches: [
        {
            id: 1,
            nome: 'Torrada',
            descricao: 'Pão, queijo duplo e catupiry',
            preco: 5.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 2,
            nome: 'Misto Quente',
            descricao: 'Pão, queijo duplo, presunto e catupiry',
            preco: 6.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 3,
            nome: 'Hamburguer',
            descricao: 'Pão, queijo, hamburguer, catupiry e salada',
            preco: 7.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 4,
            nome: 'X-Dog',
            descricao: 'Pão, queijo, presunto, salsicha, catupiry e salada',
            preco: 7.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 5,
            nome: 'X-Frango',
            descricao: 'Pão, queijo, presunto, frango, catupiry e salada',
            preco: 9.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 6,
            nome: 'X-Burg',
            descricao: 'Pão, queijo, presunto, hamburguer, catupiry e salada',
            preco: 8.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 7,
            nome: 'X-Tudo',
            descricao: 'Pão, queijo, presunto, ovo, hamburguer, salsicha, frango, catupiry e salada',
            preco: 14.00,
            imagem: 'assets/lanches/x-tudo.svg',
            destaque: 'Mais Vendido'
        },
        {
            id: 8,
            nome: 'X-Bacon',
            descricao: 'Pão, queijo, bacon, catupiry e salada',
            preco: 13.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 9,
            nome: 'X-Frango Crocante',
            descricao: 'Pão, queijo, frango, batata palha, presunto, catupiry e salada',
            preco: 12.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 10,
            nome: 'X-Calabresa',
            descricao: 'Pão, queijo, calabresa, presunto, catupiry e salada',
            preco: 13.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 11,
            nome: 'Franburg',
            descricao: 'Pão, queijo, presunto, frango, hamburguer, catupiry e salada',
            preco: 12.00,
            imagem: 'assets/lanches/lanche-padrao.svg'
        },
        {
            id: 12,
            nome: 'X-Tudo Especial',
            descricao: 'Pão, queijo, presunto, hamburguer, ovo, frango, salsicha, bacon, calabresa, catupiry e salada',
            preco: 17.00,
            imagem: 'assets/lanches/x-tudo.svg',
            destaque: 'Novo'
        }
    ],
    porcoes: [
        {
            id: 1,
            nome: 'Batata Frita',
            descricao: 'Porção de batata frita crocante com sal e orégano',
            preco: 15.90,
            imagem: 'assets/porcoes/batata.jpg'
        }
    ],
    bebidas: [
        {
            id: 1,
            nome: 'Suco de Maracujá',
            descricao: 'Suco natural de maracujá (400ml)',
            preco: 6.00,
            imagem: 'assets/bebidas/suco-maracuja.svg'
        },
        {
            id: 2,
            nome: 'Suco de Acerola',
            descricao: 'Suco natural de acerola (400ml)',
            preco: 6.00,
            imagem: 'assets/bebidas/suco-acerola.svg'
        },
        {
            id: 3,
            nome: 'Suco de Goiaba',
            descricao: 'Suco natural de goiaba (400ml)',
            preco: 6.00,
            imagem: 'assets/bebidas/suco-goiaba.svg'
        },
        {
            id: 4,
            nome: 'Refrigerante Lata',
            descricao: 'Coca-Cola, Guaraná Antarctica, Fanta ou Sprite (350ml)',
            preco: 5.00,
            imagem: 'assets/bebidas/refrigerante-lata.svg'
        },
        {
            id: 5,
            nome: 'Refrigerante 1L',
            descricao: 'Coca-Cola, Guaraná Antarctica, Fanta ou Sprite (1 litro)',
            preco: 8.00,
            imagem: 'assets/bebidas/refrigerante-1l.svg'
        },
        {
            id: 6,
            nome: 'Refrigerante 2L',
            descricao: 'Coca-Cola, Guaraná Antarctica, Fanta ou Sprite (2 litros)',
            preco: 12.00,
            imagem: 'assets/bebidas/refrigerante-2l.svg'
        }
    ]
};

// Dados das promoções
const promocoesData = [
    {
        id: 1,
        nome: 'Combo Duplo',
        descricao: '2 X-Burger + 2 Refrigerantes',
        precoAntigo: 65.80,
        precoNovo: 49.90,
        imagem: 'assets/promocoes/combo-duplo.jpg',
        destaque: 'Oferta'
    }
];

// Dados dos ingredientes adicionais
const ingredientesAdicionais = [
    {
        id: 1,
        nome: 'Hambúrguer de Boi',
        preco: 4.00
    },
    {
        id: 2,
        nome: 'Frango',
        preco: 4.00
    },
    {
        id: 3,
        nome: 'Bacon',
        preco: 4.00
    },
    {
        id: 4,
        nome: 'Calabresa',
        preco: 4.00
    },
    {
        id: 5,
        nome: 'Queijo Coalho',
        preco: 4.00
    },
    {
        id: 6,
        nome: 'Salsicha',
        preco: 3.00
    },
    {
        id: 7,
        nome: 'Batata Palha',
        preco: 2.00
    },
    {
        id: 8,
        nome: 'Ovo',
        preco: 2.00
    }
];

// Variáveis globais
let carrinho = [];

// Função para criar o card de item do cardápio
function criarCardItem(item) {
    const ingredientesHtml = ingredientesAdicionais.map(ingrediente => `
        <div class="ingrediente-adicional">
            <label>
                <input type="checkbox" data-nome="${ingrediente.nome}" data-preco="${ingrediente.preco.toFixed(2)}">
                ${ingrediente.nome} (+R$ ${ingrediente.preco.toFixed(2)})
            </label>
        </div>
    `).join('');

    // Verifica se é uma bebida
    const isBebida = item.imagem.includes('bebidas/');
    
    return `
        <div class="cardapio__item fade-in" data-preco-base="${item.preco}" data-categoria="${isBebida ? 'bebidas' : 'lanches'}">
            ${item.destaque ? `<span class="cardapio__destaque">${item.destaque}</span>` : ''}
            <img src="${item.imagem}" alt="Imagem do ${item.nome} - ${item.descricao}" loading="lazy" width="280" height="200">
            <h3>${item.nome}</h3>
            <p>${item.descricao}</p>
            ${!isBebida ? `
                <div class="cardapio__personalizacao">
                    <button class="btn-personalizar" onclick="togglePersonalizacao(this)" aria-label="Personalizar ${item.nome}">
                        Personalizar Lanche
                    </button>
                    <div class="personalizacao-content" style="display: none;">
                        <h4>Ingredientes Adicionais:</h4>
                        <div class="ingredientes-grid">
                            ${ingredientesHtml}
                        </div>
                    </div>
                </div>
            ` : ''}
            <div class="cardapio__preco">
                <div class="preco-info">
                    <span class="preco-base">R$ ${item.preco.toFixed(2)}</span>
                    ${!isBebida ? `<span class="preco-total" style="display: none;">Total: R$ ${item.preco.toFixed(2)}</span>` : ''}
                </div>
                <button class="btn btn--primary" onclick="adicionarAoCarrinho(this)" aria-label="Adicionar ${item.nome} ao carrinho">
                    Adicionar ao Carrinho
                </button>
            </div>
        </div>
    `;
}

// Função para criar o card de promoção
function criarCardPromocao(promocao) {
    return `
        <div class="promocoes__item fade-in">
            ${promocao.destaque ? `<span class="promocoes__destaque">${promocao.destaque}</span>` : ''}
            <img src="${promocao.imagem}" alt="Imagem da promoção ${promocao.nome} - ${promocao.descricao}" loading="lazy" width="280" height="200">
            <h3>${promocao.nome}</h3>
            <p>${promocao.descricao}</p>
            <div class="promocoes__preco">
                <span class="preco-antigo">De R$ ${promocao.precoAntigo.toFixed(2)}</span>
                <span class="preco-novo">Por R$ ${promocao.precoNovo.toFixed(2)}</span>
                <a href="https://wa.me/558498988389?text=Olá! Gostaria de pedir o ${promocao.nome}" 
                   class="btn btn--primary" 
                   target="_blank" 
                   rel="noopener noreferrer"
                   aria-label="Pedir ${promocao.nome} no WhatsApp">
                    Pedir no WhatsApp
                </a>
            </div>
        </div>
    `;
}

// Função para carregar itens do cardápio
function carregarCardapio(categoria) {
    const container = document.querySelector('.cardapio__items');
    const items = cardapioData[categoria];
    
    if (items) {
        container.innerHTML = items.map(criarCardItem).join('');
    }
}

// Função para carregar promoções
function carregarPromocoes() {
    const container = document.querySelector('.promocoes__grid');
    container.innerHTML = promocoesData.map(criarCardPromocao).join('');
}

// Função para alternar menu mobile
function toggleMenu() {
    const nav = document.querySelector('.header__nav');
    const btn = document.querySelector('.header__menu-btn');
    
    nav.classList.toggle('active');
    btn.classList.toggle('active');
}

// Função para rolagem suave
function scrollSuave(target) {
    const element = document.querySelector(target);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth'
        });
    }
}

// Função para alternar a visibilidade da seção de personalização
function togglePersonalizacao(button) {
    const content = button.nextElementSibling;
    const isVisible = content.style.display === 'block';
    content.style.display = isVisible ? 'none' : 'block';
    button.textContent = isVisible ? 'Personalizar Lanche' : 'Ocultar Personalização';
}

// Função para atualizar o preço total
function atualizarPrecoTotal(cardElement) {
    const precoBase = parseFloat(cardElement.dataset.precoBase);
    const checkboxes = cardElement.querySelectorAll('.ingrediente-adicional input[type="checkbox"]');
    let precoTotal = precoBase;

    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            precoTotal += parseFloat(checkbox.dataset.preco);
        }
    });

    const precoTotalElement = cardElement.querySelector('.preco-total');
    precoTotalElement.textContent = `Total: R$ ${precoTotal.toFixed(2)}`;
    precoTotalElement.style.display = 'block';

    return precoTotal;
}

// Função para adicionar item ao carrinho
function adicionarItemAoCarrinho(item, quantidade = 1, adicionais = []) {
    const itemNoCarrinho = {
        ...item,
        quantidade,
        adicionais,
        precoTotal: calcularPrecoTotal(item, quantidade, adicionais)
    };
    
    carrinho.push(itemNoCarrinho);
    atualizarCarrinho();
    mostrarNotificacao(`${item.nome} adicionado ao carrinho!`);
}

// Função para calcular preço total
function calcularPrecoTotal(item, quantidade, adicionais) {
    let precoBase = item.preco;
    let precoAdicionais = adicionais.reduce((total, adicional) => total + adicional.preco, 0);
    return (precoBase + precoAdicionais) * quantidade;
}

// Função para atualizar o carrinho
function atualizarCarrinho() {
    const carrinhoContainer = document.querySelector('.carrinho__items');
    const carrinhoTotal = document.querySelector('.carrinho__total');
    const carrinhoQuantidade = document.querySelector('.carrinho__quantidade');
    const carrinhoElement = document.querySelector('.carrinho');
    
    if (carrinhoContainer) {
        carrinhoContainer.innerHTML = carrinho.map((item, index) => `
            <div class="carrinho__item">
                <div class="carrinho__item-info">
                    <h4>${item.nome}</h4>
                    <p>Quantidade: ${item.quantidade}</p>
                    ${item.adicionais.length > 0 ? `
                        <p>Adicionais: ${item.adicionais.map(a => a.nome).join(', ')}</p>
                    ` : ''}
                    <p>R$ ${item.precoTotal.toFixed(2)}</p>
                </div>
                <button class="btn-remover" onclick="removerDoCarrinho(${index})" aria-label="Remover ${item.nome} do carrinho">
                    <img src="assets/trash.svg" alt="Remover" width="20" height="20">
                </button>
            </div>
        `).join('');
        
        const total = carrinho.reduce((sum, item) => sum + item.precoTotal, 0);
        carrinhoTotal.textContent = `Total: R$ ${total.toFixed(2)}`;
        carrinhoQuantidade.textContent = carrinho.length;

        // Mostrar ou esconder o carrinho
        if (carrinho.length > 0) {
            carrinhoElement.classList.add('active');
        } else {
            carrinhoElement.classList.remove('active');
        }
    }
}

// Função para remover item do carrinho
function removerDoCarrinho(index) {
    carrinho.splice(index, 1);
    atualizarCarrinho();
}

// Função para mostrar notificação
function mostrarNotificacao(mensagem) {
    const notificacao = document.createElement('div');
    notificacao.className = 'notificacao';
    notificacao.textContent = mensagem;
    document.body.appendChild(notificacao);
    
    setTimeout(() => {
        notificacao.remove();
    }, 3000);
}

// Função para adicionar ao carrinho (chamada pelo botão)
function adicionarAoCarrinho(button) {
    const cardElement = button.closest('.cardapio__item');
    const nomeItem = cardElement.querySelector('h3').textContent;
    const categoria = cardElement.dataset.categoria;
    const checkboxes = cardElement.querySelectorAll('.ingrediente-adicional input[type="checkbox"]:checked');
    const adicionais = Array.from(checkboxes).map(checkbox => ({
        nome: checkbox.dataset.nome,
        preco: parseFloat(checkbox.dataset.preco)
    }));
    
    const item = cardapioData[categoria].find(item => item.nome === nomeItem);
    if (item) {
        adicionarItemAoCarrinho(item, 1, adicionais);
    }
}

// Função para criar confete
function criarConfete() {
    const cores = ['#FFB800', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'];
    for (let i = 0; i < 50; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = Math.random() * 100 + 'vw';
        confetti.style.backgroundColor = cores[Math.floor(Math.random() * cores.length)];
        confetti.style.animationDelay = Math.random() * 3 + 's';
        document.body.appendChild(confetti);
        
        // Remover o confete após a animação
        setTimeout(() => {
            confetti.remove();
        }, 3000);
    }
}

// Função para abrir o modal de agradecimento
function abrirModalAgradecimento() {
    const modal = document.getElementById('modalAgradecimento');
    modal.classList.add('active');
    criarConfete();
}

// Função para fechar o modal de agradecimento
function fecharModalAgradecimento() {
    const modal = document.getElementById('modalAgradecimento');
    modal.classList.remove('active');
}

// Função para abrir o modal de endereço
function abrirModalEndereco() {
    const modal = document.getElementById('modalEndereco');
    modal.classList.add('active');
}

// Função para fechar o modal de endereço
function fecharModalEndereco() {
    const modal = document.getElementById('modalEndereco');
    modal.classList.remove('active');
}

// Função para enviar pedido com endereço
function enviarPedidoComEndereco(event) {
    event.preventDefault();
    
    const form = event.target;
    const endereco = {
        rua: form.rua.value,
        numero: form.numero.value,
        bairro: form.bairro.value,
        complemento: form.complemento.value,
        referencia: form.referencia.value
    };

    // Formata a mensagem do pedido
    let mensagem = '🛍️ *Pedido Du Carlinhos* 🛍️\n\n';
    mensagem += '*Itens do Pedido:*\n';
    
    carrinho.forEach((item, index) => {
        mensagem += `\n${index + 1}. ${item.nome}`;
        mensagem += `\n   Quantidade: ${item.quantidade}`;
        if (item.adicionais.length > 0) {
            mensagem += `\n   Adicionais: ${item.adicionais.map(a => a.nome).join(', ')}`;
        }
        mensagem += `\n   Preço: R$ ${item.precoTotal.toFixed(2)}`;
    });

    const total = carrinho.reduce((sum, item) => sum + item.precoTotal, 0);
    mensagem += `\n\n*Total do Pedido: R$ ${total.toFixed(2)}*`;
    
    // Adiciona o endereço formatado
    mensagem += '\n\n📍 *Endereço para Entrega:*';
    mensagem += `\n${endereco.rua}, ${endereco.numero}`;
    if (endereco.complemento) {
        mensagem += `\nComplemento: ${endereco.complemento}`;
    }
    mensagem += `\nBairro: ${endereco.bairro}`;
    if (endereco.referencia) {
        mensagem += `\nPonto de Referência: ${endereco.referencia}`;
    }
    mensagem += '\nJardim de Piranhas - RN';

    // Codifica a mensagem para URL
    const mensagemCodificada = encodeURIComponent(mensagem);
    
    // Abre o WhatsApp com a mensagem formatada
    window.open(`https://wa.me/558498988389?text=${mensagemCodificada}`, '_blank');
    
    // Limpa o carrinho e fecha o modal de endereço
    carrinho = [];
    atualizarCarrinho();
    fecharModalEndereco();
    
    // Abre o modal de agradecimento
    abrirModalAgradecimento();
}

// Função para finalizar pedido
function finalizarPedido() {
    if (carrinho.length === 0) {
        mostrarNotificacao('Adicione itens ao carrinho primeiro!');
        return;
    }
    
    abrirModalEndereco();
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Carregar cardápio inicial
    carregarCardapio('lanches');
    carregarPromocoes();

    // Event listeners para categorias do cardápio
    const categorias = document.querySelectorAll('.cardapio__category');
    categorias.forEach(categoria => {
        categoria.addEventListener('click', (e) => {
            // Remover classe active de todas as categorias
            categorias.forEach(cat => cat.classList.remove('active'));
            // Adicionar classe active na categoria clicada
            e.target.classList.add('active');
            // Carregar itens da categoria
            carregarCardapio(e.target.dataset.category);
        });
    });

    // Event listener para menu mobile
    const menuBtn = document.querySelector('.header__menu-btn');
    if (menuBtn) {
        menuBtn.addEventListener('click', toggleMenu);
    }

    // Event listeners para links de navegação
    const navLinks = document.querySelectorAll('.header__nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const target = link.getAttribute('href');
            scrollSuave(target);
            // Fechar menu mobile se estiver aberto
            const nav = document.querySelector('.header__nav');
            if (nav.classList.contains('active')) {
                toggleMenu();
            }
        });
    });

    // Event listener para botão "Ver Cardápio"
    const verCardapioBtn = document.querySelector('.hero__content .btn');
    if (verCardapioBtn) {
        verCardapioBtn.addEventListener('click', (e) => {
            e.preventDefault();
            scrollSuave('#cardapio');
        });
    }

    // Event listener para checkboxes de ingredientes
    document.addEventListener('change', function(e) {
        if (e.target.matches('.ingrediente-adicional input[type="checkbox"]')) {
            const cardElement = e.target.closest('.cardapio__item');
            atualizarPrecoTotal(cardElement);
        }
    });
}); 