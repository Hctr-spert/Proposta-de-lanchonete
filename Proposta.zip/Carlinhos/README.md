# Du Carlinhos - Site da Lanchonete

Site moderno e responsivo para a lanchonete Du Carlinhos, desenvolvido com foco em performance e experiência do usuário.

## 🚀 Tecnologias Utilizadas

- HTML5
- CSS3 (Flexbox e Grid)
- JavaScript (Vanilla)
- Design Responsivo
- Otimização de Imagens
- Animações CSS

## 📋 Estrutura do Projeto

```
du-carlinhos/
├── assets/
│   ├── images/
│   ├── icons/
│   └── fonts/
├── css/
│   └── style.css
├── js/
│   └── main.js
└── index.html
```

## 🎯 Funcionalidades

- Design moderno e responsivo
- Cardápio digital com categorias
- Seção de promoções
- Integração com WhatsApp para pedidos
- Mapa de localização
- Menu mobile
- Animações suaves
- Otimização para SEO

## 🛠️ Como Executar

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/du-carlinhos.git
```

2. Abra o arquivo `index.html` em seu navegador ou use um servidor local:
```bash
# Usando Python
python -m http.server 8000

# Usando Node.js
npx serve
```

## 📱 Responsividade

O site é totalmente responsivo e funciona bem em:
- Smartphones
- Tablets
- Desktops

## 🎨 Personalização

Para personalizar o site:

1. Substitua as imagens em `assets/images/`
2. Atualize os dados do cardápio em `js/main.js`
3. Modifique as cores em `css/style.css` (variáveis CSS)

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 👥 Contribuição

Contribuições são bem-vindas! Para contribuir:

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📞 Contato

Para suporte ou dúvidas, entre em contato através do email: seu-email@exemplo.com 